# Security Policy

## Supported Versions

We publish releases monthly.

| Version  | Supported          |
| -------  | ------------------ |
| >= 1.4.4 | :white_check_mark: |
| < 1.4.4  | :x:                |

## Reporting a Vulnerability

https://github.com/zeromicro/go-zero/security/advisories

Accepted vulnerabilities are expected to be fixed within a month.
