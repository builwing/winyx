Copied from https://github.com/layeh/gopher-json and https://github.com/alicebob/gopher-json
