
Credits to DmitriyVTitov on his package https://github.com/DmitriyVTitov/size
