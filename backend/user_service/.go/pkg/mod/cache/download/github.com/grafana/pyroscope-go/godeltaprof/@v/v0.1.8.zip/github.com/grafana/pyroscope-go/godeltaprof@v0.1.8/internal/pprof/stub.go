package pprof

func Runtime_cyclesPerSecond() int64 {
	return runtime_cyclesPerSecond()
}
